'''
 * Filename    : Servo_Calibration
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin, PWM
import time

pwm = PWM(Pin(19))
pwm.freq(50)
pwm.duty_u16(4800)