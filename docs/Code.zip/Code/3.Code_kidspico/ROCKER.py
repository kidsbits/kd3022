from machine import Pin
from machine import I2C
import time

I2C_ADDR = 0x39

BTN = 0x31        #按钮值
ADC1_H = 0x32        #ADC通道1 10bit
ADC1_L = 0x33        #左对齐 H[15:8] L[7:6] [5:0]为0
ADC2_H = 0x34        #ADC通道2 10bit
ADC2_L = 0x35        #左对齐 H[15:8] L[7:6] [5:0]为0

class rocker:
    def __init__(self, bus, scl, sda):
        self.bus = bus
        self.scl = scl
        self.sda = sda
        time.sleep(1)
        self.i2c = I2C(self.bus, scl = self.scl, sda = self.sda, freq = 10000)
        slv = self.i2c.scan()
        #print(slv)
        for s in slv:
            if(s == I2C_ADDR):
                self.slvAddr = s
                print('rocker found')
                #print(self.slvAddr)
                #print('rocker found')
                break
        time.sleep(1)

    def writeByte(self, addr, data):
        d = bytearray([data])
        self.i2c.writeto_mem(self.slvAddr, addr, d)
        
    def readByte(self, addr):
        return self.i2c.readfrom_mem(self.slvAddr, addr, 1)

    def readXYZ(self):
        buf1 = self.readByte(ADC1_L)
        buf2 = self.readByte(ADC1_H)
        x = ((buf1[0]>>6 | buf2[0]<<2)) & 0x3FF

        buf1 = self.readByte(ADC2_L)
        buf2 = self.readByte(ADC2_H)
        y = ((buf1[0]>>6 | buf2[0]<<2)) & 0x3FF

        buf1 = self.readByte(BTN)
        z = buf1[0]


        return (x,y,z)


