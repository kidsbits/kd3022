'''
 * Filename    : Servo
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin, PWM
import time

servo = PWM(Pin(19))
servo.freq(50)

'''
The duty cycle corresponding to the angle 
0°----2.5%----1638
67.5°----5%----3276
135‬°----7.5%----4915
202.5°----10%----6553
270°----12.5%----8191
'''
angle_0 = 1638   #the value of 0° duty cycle
angle_90 = 3801  #the value of 90° duty cycle
angle_180 = 5963 #the value of 180° duty cycle
angle_270 = 8191 #the value of 270° duty cycle

while True:
    servo.duty_u16(angle_0)
    time.sleep(1)
    servo.duty_u16(angle_90)
    time.sleep(1)
    servo.duty_u16(angle_180)
    time.sleep(1)
    servo.duty_u16(angle_270)
    time.sleep(1)