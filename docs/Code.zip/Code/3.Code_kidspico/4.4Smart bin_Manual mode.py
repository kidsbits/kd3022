'''
 * Filename    : Smart bin_Manual mode
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin,PWM
import time
from ROCKER import rocker

scl = Pin(5) 
sda = Pin(4)
bus = 0
servo = PWM(Pin(19))
servo.freq(50)
snsr = rocker (bus, scl, sda)

while True:
    x,y,z = snsr.readXYZ()
    print('y:',y)
    time.sleep(0.1)
    if 0 <= y < 490:
        servo.duty_u16(1400)
    else:
        servo.duty_u16(4800)