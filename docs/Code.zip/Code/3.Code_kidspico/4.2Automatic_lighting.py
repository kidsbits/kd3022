'''
 * Filename    : Automatic_lighting
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin,ADC
import time

led = Pin(11,Pin.OUT)
Photores = ADC(27)  

while True:
    Photores_Value = Photores.read_u16()
    print('ADC Value:',Photores_Value)
    if (Photores_Value < 10000):
        led.on()
    else:
        led.off()
    time.sleep(0.1)