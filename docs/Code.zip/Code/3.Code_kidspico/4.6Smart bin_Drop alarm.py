'''
 * Filename    : Smart bin_Drop alarm
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
from SC7A20 import sc7a20
import time

Buzzer = Pin(2,Pin.OUT)
scl = Pin(5) 
sda = Pin(4)
bus = 0
Triaxial = sc7a20(bus, scl, sda)
while True:
    tumble_count = Triaxial.tumble_handle()
    if tumble_count >= 3:  #Overturn the trash can.
        Buzzer.on()        #The buzzer alarms.
    else:                  #Place trash can flatwise.
        Buzzer.off()       #The buzzer stops emitting sounds.
    time.sleep(0.01)