'''
 * Filename    : Brightness_adjustment
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin,ADC,PWM
import time

RP = ADC(26)
led = PWM(Pin(11))
led.freq(1000)

while True:
    RP_Value = RP.read_u16()
    print('ADC Value:',RP_Value)
    led.duty_u16(RP_Value)
    time.sleep(0.1)