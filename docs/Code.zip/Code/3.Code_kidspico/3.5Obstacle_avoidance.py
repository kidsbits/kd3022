'''
 * Filename    : Obstacle_avoidance
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time
 
Obsensor = Pin(22,Pin.IN)

while True:
    print(Obsensor.value(), end='')
    if Obsensor.value() == 0:
        print('  Obstruction ahead!')
    else:
        print('  All going well!')
    time.sleep(0.1)