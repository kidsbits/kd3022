'''
 * Filename    : Manual_lighting
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time

led = Pin(11, Pin.OUT)
button = Pin(3, Pin.IN)

while True:
    if button.value() == 0:  #press button
        led.on()     # led on
    else:
        led.off()    # led off