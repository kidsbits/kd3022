'''
 * Filename    : Button
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time

button = Pin(3, Pin.IN)

while True:
    if button.value() == 0:
        print('The button is pressed!')   #Press to print message
    else:
        print('The button is not pressed!')
    time.sleep(0.1) #delay 0.1s