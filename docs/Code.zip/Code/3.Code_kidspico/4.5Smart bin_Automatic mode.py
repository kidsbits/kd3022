'''
 * Filename    : Smart bin_Automatic mode
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin,PWM
import time

servo = PWM(Pin(19))
servo.freq(50)  #T = 1/f = 20ms

def angle(x):
    return int((((x + 45) * 1.8 / 270) + 0.6 )/ 20 *65535)


Obsensor = Pin(22,Pin.IN)
Buzzer = Pin(2,Pin.OUT)

while True:
    Obsensor.value()
    if Obsensor.value() == 0: #detects something
        Buzzer.on()           #buzzer alarms
        servo.duty_u16(angle(-45))  #lid opens
    else:                     #detects nothing
        Buzzer.off()          #buzzer stays quiet
        servo.duty_u16(angle(90))  #lid closes
    time.sleep(0.5)