'''
 * Filename    : Smart bin_Automatic mode
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin,PWM
import time

Obsensor = Pin(22,Pin.IN)
Buzzer = Pin(2,Pin.OUT)
servo = PWM(Pin(19))
servo.freq(50)

while True:
    Obsensor.value()
    if Obsensor.value() == 0: #检测到有障碍物
        Buzzer.on()           #蜂鸣器响
        servo.duty_u16(1400)  #垃圾桶盖打开
    else:                     #没有检测到障碍物
        Buzzer.off()          #蜂鸣器不响
        servo.duty_u16(4800)  #垃圾桶盖闭合
    time.sleep(0.5)