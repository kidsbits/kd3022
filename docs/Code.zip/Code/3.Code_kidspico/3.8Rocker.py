'''
 * Filename    : Rocker
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time
from ROCKER import rocker

scl = Pin(5) 
sda = Pin(4)
bus = 0
snsr = rocker (bus, scl, sda)
while True:
    x,y,z = snsr.readXYZ()
    print('x:',x,'y:',y,'b:',z)
    time.sleep(0.1)