'''
SC7A20 2.0
'''

from machine import Pin
from machine import I2C
#import numpy as np
import time
import math
# import ustruct


SC7A20_I2C_ADDR = 0x19            
WHO_AM_I_REG = 0x0F

CTRL_REG1 = 0x20
CTRL_REG2 = 0x21
CTRL_REG3 = 0x22
CTRL_REG4 = 0x23
ADDR_STATUS_REG = 0x27
OUT_X_L_REG = 0x28
OUT_X_H_REG = 0x29
OUT_Y_L_REG = 0x2A
OUT_Y_H_REG = 0x2B
OUT_Z_L_REG = 0x2C
OUT_Z_H_REG = 0x2D

CHIP_ID = 0x11

tumble_count = 0
#sensor_event report = []


class sc7a20:
    def __init__(self, bus, scl, sda):
        self.bus = bus
        self.scl = scl
        self.sda = sda
        self.g = 9.8 #m/s^2
        self.tumble_count = 0

        time.sleep(1)
        self.i2c = I2C(self.bus, scl = self.scl, sda = self.sda, freq = 10000)
        slv = self.i2c.scan()
        print(slv)
        for s in slv:
            buf = self.i2c.readfrom_mem(s, WHO_AM_I_REG, 1)
            print(buf)
            if(buf[0] == 0x11):
                self.slvAddr = s
                print('sc7a20 found')
                print(self.slvAddr)
                #print('sc7a20 found')
                break
        #数据输出速度为100Hz
        self.writeByte(CTRL_REG1,0x27)  #正常模式 10HZ
        # self.writeByte(CTRL_REG1,0x37)  #正常模式 25HZ
        # self.writeByte(CTRL_REG1,0x47)  #正常模式 50HZ
        # self.writeByte(CTRL_REG1,0x57)  #正常模式 100HZ
        # self.writeByte(CTRL_REG1,0x67)  #正常模式 200HZ
        # self.writeByte(CTRL_REG1,0x77)  #正常模式 400HZ

        #配置加速度量程
        self.writeByte(CTRL_REG4,0x01) # +/-4g
        self.range = 4
        # self.writeByte(CTRL_REG4,0x00) # +/-2g
        # self.range = 2
        # self.writeByte(CTRL_REG4,0x20) # +/-8g
        # self.range = 8
        # self.writeByte(CTRL_REG4,0x30) # +/-16g
        # self.range = 16
        time.sleep(1)

    def writeByte(self, addr, data):
        d = bytearray([data])
        self.i2c.writeto_mem(self.slvAddr, addr, d)
        
    def readByte(self, addr):
        return self.i2c.readfrom_mem(self.slvAddr, addr, 1)

    def readXYZ(self):
        buf1 = self.readByte(OUT_X_L_REG)
        buf2 = self.readByte(OUT_X_H_REG)
        # 判断符号位
        twos_complement = buf1[0] + buf2[0]*256
        sign_bit = twos_complement & 0x8000  # 0x8000 是16位补码的符号位掩码
    
        # 如果是正数，直接返回
        if sign_bit == 0:
            decimal_value = twos_complement
        else:    
            # 如果是负数，进行补码到原始值的转换
            inverted_bits = twos_complement ^ 0xFFFF  # 0xFFFF 是16位补码的按位取反掩码
            decimal_value = -(inverted_bits + 1)
        
        x = (decimal_value/32767)*self.range/2
        x = x * self.g
        

        buf1 = self.readByte(OUT_Y_L_REG)
        buf2 = self.readByte(OUT_Y_H_REG)
        # 判断符号位
        twos_complement = buf1[0] + buf2[0]*256
        sign_bit = twos_complement & 0x8000  # 0x8000 是16位补码的符号位掩码
    
        # 如果是正数，直接返回
        if sign_bit == 0:
            decimal_value = twos_complement
        else:    
            # 如果是负数，进行补码到原始值的转换
            inverted_bits = twos_complement ^ 0xFFFF  # 0xFFFF 是16位补码的按位取反掩码
            decimal_value = -(inverted_bits + 1)
            
        y = (decimal_value/32767)*self.range/2
        y = y * self.g


        buf1 = self.readByte(OUT_Z_L_REG)
        buf2 = self.readByte(OUT_Z_H_REG)
        # 判断符号位
        twos_complement = buf1[0] + buf2[0]*256
        sign_bit = twos_complement & 0x8000  # 0x8000 是16位补码的符号位掩码
    
        # 如果是正数，直接返回
        if sign_bit == 0:
            decimal_value = twos_complement
        else:    
            # 如果是负数，进行补码到原始值的转换
            inverted_bits = twos_complement ^ 0xFFFF  # 0xFFFF 是16位补码的按位取反掩码
            decimal_value = -(inverted_bits + 1)
            
        z = (decimal_value/32767)*self.range/2
        z = z * self.g
        #print(x,y,z)

        return (x,y,z)
    
    def tumble_handle(self):
        x,y,z = self.readXYZ() 
        result = math.sqrt(x**2 + y**2 +z**2)
            
        angle_x = (math.atan(x / math.sqrt(y**2 + z**2))) * 180 / 3.14  #PI = 3.14
        angle_y = (math.atan(y / math.sqrt(x**2 + z**2))) * 180 / 3.14
        angle_z = (math.atan(z / math.sqrt(y**2 + x**2))) * 180 / 3.14
        #print('angle_x:',angle_x,'angle_y:',angle_y,'angle_z:',angle_z)
        
        if (abs(angle_x) > 45 or abs(angle_y) > 45) or angle_z < 0:
            self.tumble_count += 1
            if self.tumble_count >= 3:
                print('tumble')
                #self.tumble_count = 0
        else:
            self.tumble_count = 0
            print('no tumble')
        
        return self.tumble_count
        #if self.tumble_count >= 3:
            #print('tumble')
            #self.tumble_count = 0
