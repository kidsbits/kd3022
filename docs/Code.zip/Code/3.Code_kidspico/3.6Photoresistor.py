'''
 * Filename    : Photoresistor
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
# import ADC module
from machine import ADC
import time

# configuire ADC, range 0-3.3V
# define io26,io27,io28,io29 to ADC channel 0,1,2,3
Photores = ADC(27)  #or: Photores = ADC(1)
conversion_fator = 3.3 / 65535 #Voltage value of a single scale

# read ADC value every 0.1 seconds, convert the ADC value into a voltage output
while True:
    Photores_Value = Photores.read_u16()
    voltage = Photores_Value * conversion_fator
    print('ADC Value:',Photores_Value,'   Voltage:',voltage,'V')
    time.sleep(0.1)