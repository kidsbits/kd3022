'''
 * Filename    : Relay
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time

relay = Pin(8, Pin.OUT)

while True:
    relay.on()
    time.sleep(1)
    relay.off()
    time.sleep(1)