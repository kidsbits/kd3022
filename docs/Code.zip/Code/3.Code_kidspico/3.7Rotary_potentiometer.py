'''
 * Filename    : Rotary_potentiometer
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import ADC
import time

# configure ADC, range 0-3.3V
# define io26,io27,io28,io29 to ADC channel 0,1,2,3
RP = ADC(26) #or: Photores = ADC(0)
conversion_fator = 3.3 / 65535 #Voltage value of a single scale

#read ADC value every 0.1 seconds to convert it into voltage output
while True:
    RP_Value = RP.read_u16()    
    voltage = RP_Value * conversion_fator
    print('ADC Value:',RP_Value,'   Voltage:',voltage,'V')
    time.sleep(0.1)