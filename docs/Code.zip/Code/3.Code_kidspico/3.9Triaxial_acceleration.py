'''
 * Filename    : Triaxial_acceleration
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time
from SC7A20 import sc7a20

scl = Pin(5) 
sda = Pin(4)
bus = 0
Triaxial = sc7a20(bus, scl, sda)
while True:
    x,y,z = Triaxial.readXYZ()
    print('x:',x,'y:',y,'z:',z)
    time.sleep(0.1)